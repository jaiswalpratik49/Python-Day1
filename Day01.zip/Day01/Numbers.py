"""
identifiers
------------
identifiers should not strart with a number
case sensitive
should not be python keywords

"""

a = 10
b = -10

print(f"a :{a}")
print(f"b :{b}")

print(type(a))          # RTTI - runtime type identification
print(type(b))

c = 10.2
d = -5.7

print(f"c :{c}")
print(f"d :{d}")

print(type(c))
print(type(d))

e = +2e3
print(f"e :{e}")
f = -2e5
print(f"f :{f}")

d = 3 + 4j
print(f"d :{d}")
print(type(d))

e = -3 + 4j
print(e)
print(type(e))

print("Conversions".center(40, "-"))
x = 10
print(f"{type(x)}\t\t{x}")
print(f"{type(float(x))}\t\t{float(x)}")
print(f"{type(complex(x))}\t\t{complex(x)}")
print(f"{type(bool(x))}\t\t{bool(x)}")

print("Number System".center(40, "-"))
print(11)                  # decimal
print(f"0b11 :{0b11}")     # binary
print(f"0b101 :{0b101}")   # binary
print(f"0o11 :{0o11}")     # octal
print(f"0o15 :{0o15}")     # octal
print(f"0xa :{0xa}")       # hex
print(f"0xe :{0xe}")       # hex

print("Conversions".center(40, "-"))
a = 100
print(f"oct(100) :{oct(a)}")
print(f"bin(100) :{bin(a)}")
print(f"hex(100) :{hex(a)}")
