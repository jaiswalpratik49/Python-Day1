
"""
'append', 'clear', 'copy', 'count', 'extend', 'index',
'insert', 'pop', 'remove', 'reverse', 'sort'
"""
# add new values into the list - append, insert, extend

print("append".center(40, "-"))
lst = list(range(1, 11))
print(f"lst :{lst}")

lst.append(11)
lst.append(12)
print(f"lst :{lst}")
lst.append([13, 14, 15])
print(f"lst :{lst}")

print(f"lst[12] :{lst[12]}")
print(f"lst[12][0:2] :{lst[12][0:2]}")

print("extend".center(40, "-"))
lst = list(range(1, 15, 2))
print(f"lst :{lst}")
lst.extend([17, 19, 21])
print(f"lst :{lst}")
lst.extend([23])
print(f"lst :{lst}")

print("insert".center(40, "-"))
lst = list(range(10, 101, 10))
print(f"lst :{lst}")
lst.insert(4, 45)
lst.insert(6, 55)
print(f"lst :{lst}")
lst.insert(8, [61, 62, 63, 64, 65])
print(f"lst :{lst}")

# remove elements from the list - pop, remove, clear

print("pop".center(40, "-"))
lst = list(range(1, 11))
print(f"lst :{lst}")
res = lst.pop(4)
print(f"res :{res}")
print(f"lst :{lst}")

print("-" * 40)
res = lst.pop()
print(f"res :{res}")
print(f"lst :{lst}")

print("remove".center(40, "-"))
lst = list(range(1, 11))
print(f"lst :{lst}")

res = lst.remove(5)
print(f"res :{res}")
print(f"lst :{lst}")

# cannot skip the argument passed to remove
# lst.remove(5)

print("clear".center(40, "-"))
lst = list(range(1, 6))
print(f"lst :{lst}")
lst.clear()
print(f"lst :{lst}")
