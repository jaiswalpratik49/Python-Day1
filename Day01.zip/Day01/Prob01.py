
n = 0
for Number in range(50, 151):
    count = 0
    for i in range(2, (Number // 2 + 1)):
        if Number % i == 0:
            count = count + 1
            break
    if count == 0 and Number != 1:
        print(Number, end=" ")
        n += 1
print()
print(f"There are {n} prime numbers between 150 and 50")