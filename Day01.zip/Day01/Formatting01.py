
# c style
st = "Welcome %s, what a %s player"
print(st)
values = ("Sachin", "class")
print(st % values)

print("-" * 40)
print("Welcome %s, what a %s player" % ("Sachin", "class"))

print("-" * 40)
print("Welcome %s, what a %s player with a rating %d" % ("Sachin", "class", 4))
print("Welcome %s, what a %s player with a rating %.2f" % ("Sachin", "class", 4))
print("Welcome %s, what a %s player with a rating %.2f" % ("Sachin", "class", 4.4897545))

# unix style
print("-" * 40)
from string import Template
tmp = Template("Welcome $name, what a $adj player")
print(tmp)
res = tmp.substitute(name="Rahul", adj="superb")
print(res)

# format string in python
print("-" * 40)
print("Welcome {}, what a {} player from {}".format("Rahul", 'superb', 'India'))

print("-" * 40)
print("Welcome {0}, what a {1} player from {2}".format("Rahul", 'superb', 'India'))

print("-" * 40)
print("Welcome {1}, what a {2} player from {0}".format('India', "Rahul", 'superb'))

print("-" * 40)
print("Welcome {gname}, what a {adj} player from {0}".format('India', gname="Rahul", adj='superb'))

# interpolation
print("-" * 40)
from math import pi, e

print(f"PI = {pi} and eulers constant = {e}")

print("-" * 40)
print("PI={} and Eulers Constant {}".format(pi, e))

print("PI={} and Eulers Constant {} and magic number is {}".format(pi, e, 40585))

print("PI={0} and Eulers Constant {1} and magic number is {magic}".format(pi, e, magic=40585))
