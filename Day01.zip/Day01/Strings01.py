"""
strings are immutable

"""

st = "Hello World"
print(f"st :{st}")
print(type(st))

print(f"st[0] :{st[0]}")        # strings are stored like a list(array)
print(f"st[6] :{st[6]}")
print(f"st[10] :{st[10]}")

print("reverse indexing".center(40, "-"))
print(f"st[-1] :{st[-1]}")
print(f"st[-5] :{st[-5]}")
print(f"st[-11 :{st[-11]}")

print("slicing".center(40, "-"))
print(st[0:5])
print(st[6:11])
print(st[0:])
print(st[:11])
print(st[0:11:2])
print(st[:])

print("-" * 40)
print(st[-1:-6:-1])
print(st[-7:-12:-1])
print(st[-1:-12:-1])
print(st[-1::-1])
print(st[:-12:-1])
print(st[::-1])


print("-" * 40)
# print(dir(st))

print(f"st: {st}")
print(st.upper())

print(f"st[6] :{st[6]}")
# st[6] = "w"
