
l1 = list()
print(f"l1 :{l1}")
print(type(l1))

print("-" * 40)
l2 = list(range(1, 11))
print(f"l2 :{l2}")
print(type(l2))

print("-" * 40)
l3 = [1, 2, 3, 4, 5]
print(f"l3 :{l3}")
print(type(l3))

print("-" * 40)
lst = [1, 2, 3, 4, 'five', 'six', 'seven', 8.5, 9.99, 10.3, True, False, 3+4j]
print(f"lst :{lst}")

# indexes that starts from 0
print(f"lst[0] :{lst[0]}")
print(f"lst[6] :{lst[6]}")

print("-" * 40)
# addresses
print(lst[0]," :", id(lst[0]))
print(lst[1]," :", id(lst[1]))
print(lst[2]," :", id(lst[2]))
print(lst[3]," :", id(lst[3]))
print(lst[4]," :", id(lst[4]))

print("-" * 40)
# reverse index
print(f"lst[-1] :{lst[-1]}")
print(f"lst[-9] :{lst[-9]}")

print("-" * 40)
# slicing
print(f"lst[2:9] :{lst[2:9]}")
print(f"lst[8:14] :{lst[8:14]}")
print(f"lst[0:] :{lst[0:]}")
print(f"lst[:14] :{lst[:14]}")
print(f"lst[0::2] :{lst[0::2]}")

print("-" * 40)
# reverse
print(f"lst[-1:-6:-1] :{lst[-1:-6:-1]}")
print(f"lst[-1:-16:-2 :{lst[-1:-16:-2]}")
print(f"lst[::-1] :{lst[::-1]}")

print("-" * 40)
print(f"lst :{lst}")
lst[3] = 44
print(f"lst :{lst}")
# lst[15] = "abc"

print("-" * 40)
print(dir(lst))