
emp = "1059, Michael, 34, MGR, Finance"
print(f"emp :{emp}")
res = emp.split(", ")       # convert a string to a list
print(f"res :{res}")
print(f"Name : {res[1]}")
print(f"Dept : {res[-1]}")

print(f"emp :{emp}")
st = ",".join(res)
print(st)
print(type(st))

st = "hello world"
a = ('helowrd')
b = ('HELOWRD')

tbl = st.maketrans(a, b)
print(tbl)
print(ord("h"), " : ", ord("H"))

res = st.translate(tbl)
print(f"res :{res}")

print("-" * 40)
st = "the quick brown fox jumps over the lazy dog"
print(st)

res = st.find('fox')
print(f'res :{res}')

print("-" * 40)
print(f"st :{st}")

res = st.replace("the", "The", 1)
print(f"res :{res}")

print("-" * 40)
# st = "hello"
# st is an object of str class
# str class does not have a setter method

