
print("count".center(40, "-"))
lst = [1, 2, 1, 2, 3, 1, 4, 2, 1, 3, 2, 1, 5, 2, 1, 4, 1]
print(f"lst :{lst}")
print("1 :", lst.count(1))
print("2 :", lst.count(2))
print("3 :", lst.count(3))

print("index".center(40, "-"))
lst = [1, 2, 1, 2, 3, 1, 4, 2, 1, 3, 2, 1, 5, 2, 1, 4, 1]
print(f"lst :{lst}")
res = lst.index(4)
print(f"Index of 4 :{res}")
# stop position is not mandatory
res = lst.index(4, 7)
print(f"Index of 4 2nd time :{res}")

print("copy".center(40, "-"))
lst1 = [1, 2, 3, 4, 5]
print(f"Before lst1 :{lst1}")
lst2 = lst1                 # shallow copy
print(f"Before lst2 :{lst2}")

print("-" * 40)
lst2.insert(3, [10, 20, 30])
print(f"After lst1 :{lst1}")
print(f"After lst2 :{lst2}")

print("-" * 40)
lst3 = [5, 6, 7, 8, 9]
print(f"Before lst3 :{lst3}")
lst2 = lst3.copy()           # deep copy
print(f"Before lst2 :{lst2}")

print("-" * 40)
lst2.insert(2, [10, 20, 30, 40, 50])
print(f"After lst2 :{lst2}")
print(f"After lst3 :{lst3}")

# flaw copy function