
for i in range(1, 11):
    print(i, end=" ")
print()

print(f"i :{i}")

while(i > 0):
    print(i, end= " ")
    i -= 1      # i = i - 1
print()

print("-" * 40)

for i in range(1, 11):
    if i % 2 == 1:
        continue
    if i > 8:
        break
    print(i, end=" ")
else:
    print("else part of for loop")