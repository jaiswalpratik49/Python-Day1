
# conversions
print("{val} {val} {val}".format(val="A"))
print("{val!s} {val!r} {val!a}".format(val="A"))

print("The number is {num} {num} {num}".format(num=45))
print("The number is {num} {num:f} {num:b}".format(num=45))
print("The number is {num:10} {num:f} {num:b}".format(num=45))
print("The number is {num:5} {num:f} {num:b}".format(num=45))
print("The number is {num:5} {num:f} {num:b}".format(num=4589012))

print("{num:10}years, India is great".format(num=75))
print("{num:<10}years, India is great".format(num=75))
print("{num:^25}years, India is great".format(num="seventy five"))
print("{num:>25}years, India is great".format(num="seventy five"))


